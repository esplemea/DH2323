# DH2323 - UP! Project

Authors:

Zac Cook, Virgile Hernicot, Nicolas Zimmermann.

Archive content:

- project report (PDF)
- source code (Processing project)
- runnables (Windows and Linux)

Instructions:

The program can be run through Processing or using one of the runnable files.
To navigate in the scene, use the arrow keys to move around. To add balloons,
hit Ctrl and click where you want to place it.
